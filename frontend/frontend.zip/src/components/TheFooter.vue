<template>
       <footer class="p-5 pb-0 bg-light border">
      <h5>안녕🖐 나는 <code>footer</code>라고 해</h5>
      <hr class="mb-4" />
      <p>
      <span class="text-muted">황영</span><span class="font-size-2">준</span><span class="text-muted">, 이현</span><span class="font-size-2">정</span><span class="text-muted">의 해피</span><span class="font-size-2">하우스</span>에 대해서 더 알고싶다면?
      </p>
      <p>
      Noh's&nbsp;
        <a class="link-none" href="mailto:jinhyeon.noh@gmail.com">✉️ Mail</a> | 
        <a class="link-none" href="https://www.github.com/nohhow">📁 Github</a> 
        <br/>
      Lee's&nbsp;
        <a class="link-none" href="mailto:02q09q@gmail.com">✉️ Mail</a> | 
        <a class="link-none" href="https://github.com/hjle2">📁 Github</a> 
      </p>
      <p class="text-muted">Copyright by SSAFY. All rights reserved.</p>
    </footer>
</template>

<script>
export default {

}
</script>

<style>

</style>